<?php 
include "connection.php";
// sql to create table courses
$role_table="CREATE TABLE if NOT EXISTS  roles (
  role_id INT  AUTO_INCREMENT PRIMARY KEY,
  role_name VARCHAR(30) NOT NULL,
  created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_date  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  )";
   if ($conn->query($role_table) == TRUE) {
      // echo "Table roles created successfully";
    } else {
      echo "Error creating  role table: " ;
    }
$courses_table="CREATE TABLE if NOT EXISTS  courses (
    course_id INT  AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(30) NOT NULL,
    user_id INT REFERENCES users(user_id),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
     if ($conn->query($courses_table) == TRUE) {
        // echo "Table courses created successfully";
      } else {
        echo "Error creating  courses table: " ;
      }
      
// sql to create table user_table
  $user_table = "CREATE TABLE if NOT EXISTS  users(
    user_id INT  AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(30) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    role_id INT REFERENCES roles(role_id),
    pass VARCHAR(50) NOT NULL,
    email_verfied  int NOT NULL DEFAULT '0',
    reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reg_updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($user_table) == TRUE) {
      // echo "Table user_table created successfully";
    } else {
      echo "Error creating user table: ";
    }
    $options_table = "CREATE TABLE if NOT EXISTS  options (
       option_id INT  AUTO_INCREMENT PRIMARY KEY,
       option_ TEXT,
       question_id INT REFERENCES questions(question_id),
       isscorrect BOOLEAN,
       created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       updated_date  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        
        )";
        
        if ($conn->query( $options_table) == TRUE) {
          // echo "Table options created successfully";
        } else {
          echo "Error creating options_table table: ";
        }
      $question_table = "CREATE TABLE if NOT EXISTS questions (
        question_id INT  AUTO_INCREMENT PRIMARY KEY,
        question  TEXT,
        user_id INT REFERENCES users(user_id),
        course_id INT REFERENCES courses(course_id) ,
        correct_option_id INT REFERENCES options(option_id)
        
        )";
        
        if ($conn->query($question_table) == TRUE) {
          // echo "Table question_table created successfully";
        } else {
          echo "Error creating question table: " ;
        }
    
?>