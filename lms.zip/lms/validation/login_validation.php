<?php 

$errors = [];
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  // getting value

  $email=$_POST['email'];
  $pass=md5($_POST['password']);

  // error check

  include "validation_class.php";
  $errors['email']=$check->email($email);
  $errors['pass']=$check->password($pass);

// connection + query run



if($errors['email']=="" && $errors['pass']==""){
 // connection and insertion file

 require "./database/database.php";
$search="SELECT * FROM `users` WHERE `user_email` LIKE '$email' AND `user_password` LIKE '$pass'";
$res=$db_obj->read($search);

if($res){
if($res['is_verified']){
  if($res['roll_id']==1){
    header('Location:./admin/');
  }else{
    header('Location:./student/');
  }
}else{
   echo $res['user_id'];
  // header('Location:./services/email_verification.php?uid=$id');
}
}else{
 echo "Email/Password didn't Match";
}

}


  


 

}
