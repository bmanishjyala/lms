<?php 

$errors = [];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name=$_POST['name'];
  $registerAs=$_POST['register_as'];
 
  $email=$_POST['email'];
  $mobile=$_POST['number'];
  $pass=$_POST['password'];
  $cfnpass=$_POST['confirmpassword'];


  
  // validation class

  require 'validation_class.php';

  // validation check

if($registerAs ==""){
  $errors['register']="Register As Teacher or Student ";
}
 $errors['name']= $check->name($name);
   $errors['email']=$check->email($email);
   $errors['contact']=$check->contact($mobile);
   $errors['pass']=$check->password($pass);
   $errors['cfnpass']=$check->confirm_password($cfnpass,$pass);
   
   
   $encrypt_pass=md5($pass);

 if($errors['name']=="" && $errors['email']=="" && $errors['contact']=="" && $errors['pass']=="" && $errors['cfnpass']=="" && $errors['register']==""){

  // connection and insertion file

  require "./database/database.php";
$insertQuery="INSERT INTO `users`(`user_name`, `user_email`, `user_contact`, `user_password`, `roll_id`, `created_at`) VALUES ('$name','$email','$mobile','$encrypt_pass','$registerAs',now())";
 $res=$db_obj->write($insertQuery);
 if($res){
 header('Location:./index.php');
 }else{
  echo "Not Inserted";
 }

 }



}
?>